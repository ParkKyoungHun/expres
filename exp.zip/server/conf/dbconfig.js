module.exports = {
    host     : 'localhost',
    user     : 'root',
    password : 'r1r2r3',
    port     : '3306',
    database : 'ang2'
  };